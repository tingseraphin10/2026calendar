const months = [
    { name: "JANUARY", days: 31, color: "#007BFF" },
    { name: "FEBRUARY", days: 28, color: "#FF5733" },
    { name: "MARCH", days: 31, color: "#28A745" },
    { name: "APRIL", days: 30, color: "#800080" },
    { name: "MAY", days: 31, color: "#5F9EA0" },
    { name: "JUNE", days: 30, color: "#FFA500" },
    { name: "JULY", days: 31, color: "#007BFF" },
    { name: "AUGUST", days: 31, color: "#FF5733" },
    { name: "SEPTEMBER", days: 30, color: "#28A745" },
    { name: "OCTOBER", days: 31, color: "#800080" },
    { name: "NOVEMBER", days: 30, color: "#5F9EA0" },
    { name: "DECEMBER", days: 31, color: "#FFA500" }
];

function generateCalendar() {
    const calendarContainer = document.getElementById('calendar');
    
    months.forEach((month, index) => {
        const monthDiv = document.createElement('div');
        monthDiv.classList.add('month');
        monthDiv.style.borderColor = month.color;

        const header = createHeader(month);
        monthDiv.appendChild(header);

        const weekdaysDiv = createWeekdays();
        monthDiv.appendChild(weekdaysDiv);

        const daysDiv = createDays(month, index);
        monthDiv.appendChild(daysDiv);

        calendarContainer.appendChild(monthDiv);
    });
}

function createHeader(month) {
    const header = document.createElement('div');
    header.classList.add('calendar-header');
    header.style.backgroundColor = month.color;
    header.innerHTML = `
        <h2>${month.name}</h2>
    `;
    return header;
}

function createWeekdays() {
    const weekdaysDiv = document.createElement('div');
    weekdaysDiv.classList.add('weekdays');
    weekdaysDiv.innerHTML = `
        <div class="weekday">Su</div>
        <div class="weekday">Mo</div>
        <div class="weekday">Tu</div>
        <div class="weekday">We</div>
        <div class="weekday">Th</div>
        <div class="weekday">Fr</div>
        <div class="weekday">Sa</div>
    `;
    return weekdaysDiv;
}

function createDays(month, index) {
    const daysDiv = document.createElement('div');
    daysDiv.classList.add('days');

    const firstDay = new Date(`2026-${index + 1}-01`).getDay();
    

    for (let i = 0; i < firstDay; i++) {
        const emptyDiv = document.createElement('div');
        emptyDiv.classList.add('day', 'empty');
        daysDiv.appendChild(emptyDiv);
    }


    for (let day = 1; day <= month.days; day++) {
        const dayDiv = document.createElement('div');
        dayDiv.classList.add('day');
        dayDiv.textContent = day;
        daysDiv.appendChild(dayDiv);
    }

    return daysDiv;
}

generateCalendar();
